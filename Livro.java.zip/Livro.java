package biblioteca.entidades;

public class Livro {

		private int id;
		private String titulo;
		private String genero;
		private boolean emprestado;
		
		public Livro(int id, String titulo, String genero, boolean emprestado){
			this.id=id;
			this.titulo = titulo;
			this.genero = genero;
			this.emprestado = false;
		}
		@Override
		public String toString() {
			return "Livro[id = " + id + ",titulo = " + ",genero = " + genero + ",emprestado = " + emprestado + "]";
	
 }
			
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getTitulo() {
			return titulo;
		}
		public void setTitulo(String titulo) {
			this.titulo = titulo;
		}
		public String getGenero() {
			return genero;
		}
		public void setGenero(String genero) {
			this.genero = genero;
		}
		public boolean isEmprestado() {
			return emprestado;
		}
		public void setEmprestado(boolean emprestado) {
			this.emprestado = emprestado;
		}
		}