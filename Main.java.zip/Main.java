package biblioteca.entidades;

import java.util.Scanner;

public class Main {

	public static void main11(String[] args) {

		Biblioteca biblioteca = new Biblioteca();
		
		int op = 0;
		Scanner ler = new Scanner(System.in);

		while(op != 11) {
				System.out.println("       Menu Da Biblioteca        ");
				System.out.println();
				System.out.println("1- Cadastrar Livro ");
				System.out.println("2- Consultar Livro ");
				System.out.println("3- Alterar Livro ");
				System.out.println("4- Remover Livro ");
				System.out.println();
				System.out.println("5- Cadastrar Aluno ");
				System.out.println("6- Consultar Aluno ");
				System.out.println("7- Alterar Senha ");
				System.out.println("8- Remover Aluno ");
				System.out.println();
				System.out.println("9- Fazer Empréstimo de Livro ");
				System.out.println("10- Consultar Empréstimo ");
				System.out.println();
				System.out.println("11- Encerrar.");
				System.out.println();
				System.out.println("Digite sua opção: ");
			
			op = ler.nextInt();
			
			switch (op) {
			case 1:
				System.out.println("Digite o ID: ");
				int id = ler.nextInt();
				/* String idD = ler.nextLine();
				 * int id = Integer.valueOf(idD);
				 */
				
				System.out.println("Digite o Titulo do Livro: ");
				String titulo = ler.next();
				
				System.out.println("Digite o Genero do Livro : ");
				String genero = ler.next();
				
				Livro livro = new Livro(id, titulo, genero);
				
				biblioteca.cadastrarLivro(livro);
				biblioteca.consultarLivro();
				break;
				
			case 2:
				System.out.println("Digite o ID: ");
				int id1 = ler.nextInt();
				System.out.println(biblioteca.consultarLivro(id1));
				break;
				
			case 3:
				System.out.println("Digite o novo ID: ");
				int id2 = ler.nextInt();
				
				System.out.println("Digite o novo Titulo: ");
				String titulo2 = ler.next();
				
				System.out.println("Digite o novo Genero: ");
				String genero2 = ler.next();
				
				biblioteca.alterarLivro(id2, titulo2, genero2);
				 
				System.out.println(biblioteca.consultarLivro(id2));
				break;
				
			case 4: 
				System.out.println("Digite o ID: ");
				int id3 = ler.nextInt();
				biblioteca.removerLivro(id3);
				biblioteca.consultarLivro();
				break;
				
			case 5:
				System.out.println("Digite a Matricula: ");
				int matricula = ler.nextInt();
				/* String matricula = ler.nextLine();
				 * int matricula = Integer.valueOf(matricula);
				 */
			
				System.out.println("Digite O Nome do Aluno: ");
				String nome = ler.next();
				
				System.out.println("Digite A Senha: ");
				int senha = ler.nextInt();
				
				Aluno aluno = new Aluno(matricula, nome, senha);
				
				biblioteca.cadastrarAluno(aluno);
				biblioteca.consultarAluno();
				break;
			
			case 6:
				System.out.println("Digite a Matricula do Aluno: ");
				int matricula1 = ler.nextInt();
				System.out.println(biblioteca.consultarAluno(matricula1));
				break;
			
			case 7:
				System.out.println("Digite a Matricula: ");
				int matricula2 = ler.nextInt();
				
				System.out.println("Digite o Nome: ");
				String nome2 = ler.next();
				
				System.out.println("Digite a Nova Senha: ");
				int senha2 = ler.nextInt();
				
				biblioteca.alterarAluno(matricula2, nome2, senha2);
				
				System.out.println(biblioteca.consultarAluno(matricula2));
				break;
			
			case 8:
				System.out.println("Digite a Matricula: ");
				int matricula3 = ler.nextInt();
				biblioteca.removerAluno(matricula3);
				biblioteca.consultarAluno();
				break;
				
			case 9:
				System.out.println("Digite Matricula do Aluno: ");
				int matriculaAluno = ler.nextInt();
				biblioteca.consultarLivro();
				
				System.out.println();
				System.out.println("Digite ID do livro: ");
				int idLivro = ler.nextInt();
				biblioteca.emprestarLivro(matriculaAluno, idLivro);
				break;
				
			case 10:
				System.out.println("Digite ID do Livro: ");
			    int idLivro1 = ler.nextInt();
			
				biblioteca.mostrarLivrosEmprestados(idLivro1);
			    break;
			    
			case 11:
				break;
				
			default:
				break;
			}
		}
		
		ler.close();
	}
}

	

