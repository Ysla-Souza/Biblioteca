package biblioteca.entidades;

import java.util.ArrayList;
import java.util.List;

 public class Biblioteca {

	 private List<Aluno>alunos;
	 private List<Livro>livros;
	 
	 public Biblioteca () {
		 this.alunos = new ArrayList<Aluno>();
		 this.livros = new ArrayList<Livro>();
	 }
	 
	 public void cadastrarLivro(Livro livro) {
		 this.livros.add(livro); 
		 
	 }

	 public void consultarLivro() {
		 for(Livro livro:livros) {
			 System.out.println(livro);
		 }
	 }
	 
	 public Livro consultarLivro(int id) {
		 Livro resultado = null;
		 for(Livro livro:livros) {
			 if(livro.getId() == id) {
				 resultado = livro;
			 }
		 }
		 return resultado;
	 }
		 
	 public void alterarLivro(int IdAlteracao, String titulo, String genero) {
		 Livro alterado = new Livro(IdAlteracao, titulo, genero, false);
		 for(Livro livro:livros) {
			 if(livro.getId() == IdAlteracao);{
			 int indice = livros.indexOf(livro);
			 livros.set(indice, alterado); 		 
			 
		 }
	 }
	 }
	 
	 public void removerLivro(int id) {
		 for(Livro livro:livros) {
			 if(livro.getId()== id) {
				 livros.remove(livro);
				 break;
				 
				 }
			 }
				 
			 }
		 public void cadastrarAluno(Aluno aluno) {
			 this.alunos.add(aluno); 
			 
		 }

		 public void consultarAluno() {
			 for(Aluno aluno:alunos) {
				 System.out.println(aluno);
			 }
		 }
		 
		 public Aluno consultarAluno(int matricula) {
			 Aluno resultado = null;
			 for(Aluno aluno:alunos) {
				 if(aluno.getMatricula() == matricula) {
					 resultado = aluno;
				 }
			 }
			 return resultado;
		 }
			 
		 public void alterarAluno(int SenhaAlteracao, String nome, int matricula) {
			 Aluno alterado = new Aluno(SenhaAlteracao, nome, matricula);
			 for(Aluno aluno:alunos) {
				 if(aluno.getSenha() == SenhaAlteracao);{
				 int indice = alunos.indexOf(aluno);
				 alunos.set(indice, alterado); 		 
				 
			 }
		 }
		 }
		 
		 public void removerAluno(int Matricula) {
			 for(Aluno aluno:alunos) {
				 if(aluno.getMatricula()== Matricula) {
					 alunos.remove(aluno);
					 break;
		 }
			 }
	 }
		 public void emprestarLivro(int id) {
				for (Livro livro : livros) {
					if (livro.getId() == id) {
						System.out.println("Livro disponível para uso!");
						livros.remove(livro);	
					}
					else {
						System.out.println("Livro já está em uso!");
					}
				}
			
		}
 }