package biblioteca.entidades;

public class Aluno {

	private int matricula;
	private String nome;
	private int senha; 
	
	public Aluno(int matricula, String nome, int senha) {
			this.matricula = matricula;
			this.nome = nome;
			this.senha = senha;
	}
	
	@Override
	public String toString() {
		return"Aluno[matricula = " + matricula +",nome = " + nome + ",senha = " + senha + "]";
	}
	
	public int getMatricula() {
		return matricula; 
	}
	
	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getSenha() {
		return senha;
	}

	public void setSenha(int senha) {
		this.senha = senha;
	}
}


